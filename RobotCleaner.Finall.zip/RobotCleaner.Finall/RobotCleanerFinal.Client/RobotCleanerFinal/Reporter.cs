﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace RobotCleanerFinal
{
    public class Reporter : IReport
    {
        readonly SortedSet<Position> cleanedLocations;

        public Reporter()
        {
            cleanedLocations = new SortedSet<Position>();
        }

        public string ReportOutPut()
        {
            return string.Format("=> Cleaned: {0}", cleanedLocations.Count);
        }

        public void RegisterNewPosition(Position position)
        {
            cleanedLocations.Add(position);
        }
    }
}

