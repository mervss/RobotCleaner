﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RobotCleanerFinal
{
    public class CommandSet
    {
        private int commandsCount;
        public int CommandsCount
        {
            get
            {
                return commandsCount;
            }
            set
            {
                commandsCount = value;
            }
        }

        private Position beginningPosition;
        public Position BeginningPosition
        {
            get
            {
                return beginningPosition;
            }
            set
            {
                beginningPosition = value;
            }
        }

        private List<MoveForwardCommand> moveCommands;

        public List<MoveForwardCommand> MoveCommands
        {
            get { return moveCommands; }
        }

        public CommandSet()
        {
            moveCommands = new List<MoveForwardCommand>();
        }
    }
}
