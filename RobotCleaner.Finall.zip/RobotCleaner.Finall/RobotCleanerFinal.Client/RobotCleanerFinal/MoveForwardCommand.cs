﻿ using System;
 using System.Collections.Generic;
 using System.Linq;
 using System.Text;
 using System.Threading.Tasks;

    namespace RobotCleanerFinal
    {
        public class MoveForwardCommand
        {
            internal Direction MoveDirection { get; set; }
            internal int MoveSteps { get; set; }
        }
    }
