﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace RobotCleanerFinal
{
    public class Robot
    {
        public Position Position { get; set; }
        private CommandSet commandSet;
        private readonly IReport reporter;
        private readonly Position bottomLeft;
        private readonly Position topRight;


        public Robot(CommandSet cmdSet, IReport reportOutput) : this(cmdSet, reportOutput, null, null)
        {
        }

        public Robot(CommandSet cmdSet, IReport reportOutput, Position blBound, Position trBound)
        {
            commandSet = cmdSet;
            Position = commandSet.BeginningPosition;
            reporter = reportOutput;
            bottomLeft = blBound;
            topRight = trBound;
        }

        public void ExecuteCommands()
        {
            foreach (MoveForwardCommand cmd in commandSet.MoveCommands)
            {
                for (int i = 0; i < cmd.MoveSteps; i++)
                {
                    MoveRobot(cmd);
                }
            }
        }

        private void MoveRobot(MoveForwardCommand cmd)
        {
            switch (cmd.MoveDirection)
            {
                case Direction.North:
                    Position = new Position(Position.X, Position.Y + 1);
                    break;
                case Direction.East:
                    Position = new Position(Position.X + 1, Position.Y);
                    break;
                case Direction.South:
                    Position = new Position(Position.X, Position.Y - 1);
                    break;
                case Direction.West:
                    Position = new Position(Position.X - 1, Position.Y);
                    break;

                default:
                    break;
            }

            Position.Validate(bottomLeft, topRight);

            if (reporter != null)
                reporter.RegisterNewPosition(Position);
        }

        public string ReportOutPut()
        {
            if (reporter == null)
            {
                return "=> Cleaned:unknown";
            }
            return reporter.ReportOutPut();
        }
    }
}

