﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using RobotCleanerFinalLibrary;

namespace RobotCleanerFinal.Test
{
    [TestClass]
    public class PositionTest
    {
        [TestMethod]
        public void CreatePosition_CurrentPosition()
        {
            Position position = new Position(100, 300);

            Assert.AreEqual(100, position.X);
            Assert.AreEqual(300, position.Y);
        }

        [TestMethod]
        public void ComparePosition_TwoPositionsSmallXBigX()
        {
            Position location1 = new Position(100, 100);
            Position location2 = new Position(200, 100);

            Assert.AreEqual(-1, location1.CompareTo(location2));
        }

        [TestMethod]
        public void CompareLocation_TwoPositionsSmallYBigY()
        {
            Position location1 = new Position(200, 200);
            Position location2 = new Position(200, 400);

            Assert.AreEqual(1, location1.CompareTo(location2));
        }

        [TestMethod]
        public void CompareLocation_TwoPositionsSameXandY()
        {
            Position location1 = new Position(100, 200);
            Position location2 = new Position(100, 200);

            Assert.AreEqual(0, location1.CompareTo(location2));
        }
    }
}

