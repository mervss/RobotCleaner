﻿using RobotCleanerFinalLibrary;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RobotCleanerFinal.Test
{
    class TestReporter : IReport
    {
        public string ReportOutPut()
        {
            return "=> Cleaned: 0";
        }

        public void RegisterNewPosition(Position Position)
        {

        }
    }
}

