﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using RobotCleanerFinalLibrary;

namespace RobotCleanerFinal.Test

{
    [TestClass]
    public class CommandFactoryTest
    {
        [TestMethod]
        public void CreateCommandFactory_AddTwoInputs()
        {
            CommandFactory commandFactory = new CommandFactory();
            commandFactory.AddInputs("2");
            commandFactory.AddInputs("10 22");
            commandFactory.AddInputs("E 2");
            commandFactory.AddInputs("N 1");

            Assert.IsTrue(commandFactory.IsInputComplete);
        }
        [TestMethod]
        public void CreateCommandFactory_FourCommandsTest()
        {
            CommandFactory commandFactory = new CommandFactory();
            commandFactory.AddInputs("4");
            commandFactory.AddInputs("10 22");
            commandFactory.AddInputs("E 2");
            commandFactory.AddInputs("W 2");
            commandFactory.AddInputs("N 1");
            commandFactory.AddInputs("S 2");

            Assert.IsTrue(commandFactory.IsInputComplete);
        }

        [TestMethod]
        public void CreateCommandFactory_ZeroCommandTest()
        {
            CommandFactory commandFactory = new CommandFactory();
            commandFactory.AddInputs("0");
            commandFactory.AddInputs("10 22");

            Assert.IsTrue(commandFactory.IsInputComplete);
        }

        [TestMethod]
        public void CreateCommandFactory_TenThousandCommandsTest()
        {
            CommandFactory commandFactory = new CommandFactory();
            commandFactory.AddInputs("10000");
            commandFactory.AddInputs("10 22");

            for (int i = 0; i < 10000; i++)
            {
                commandFactory.AddInputs("N 1");
            }

            Assert.IsTrue(commandFactory.IsInputComplete);
        }

        [TestMethod]
        public void CreateCommandFactory_NegativeCommandsTest()
        {
            CommandFactory commandFactory = new CommandFactory();
            commandFactory.AddInputs("-100");
            commandFactory.AddInputs("10 22");

            Assert.IsTrue(commandFactory.IsInputComplete);
        }

        [TestMethod]
        public void CreateCommandFactory_NormalPositionTest()
        {
            CommandFactory commandFactory = new CommandFactory();
            commandFactory.AddInputs("0");
            commandFactory.AddInputs("10 22");

            Assert.AreEqual(10, commandFactory.commandSet.BeginningPosition.X);
            Assert.AreEqual(22, commandFactory.commandSet.BeginningPosition.Y);
        }

        [TestMethod]
        public void CreateCommandFactory_TabSeparatorPositionTest()
        {
            CommandFactory commandFactory = new CommandFactory();
            commandFactory.AddInputs("0");
            commandFactory.AddInputs("10\t22");

            Assert.AreEqual(10, commandFactory.commandSet.BeginningPosition.X);
            Assert.AreEqual(22, commandFactory.commandSet.BeginningPosition.Y);
        }

        [TestMethod]
        public void CreateCommandFactory_SingleMoveForwardTest()
        {
            CommandFactory commandFactory = new CommandFactory();
            commandFactory.AddInputs("2");
            commandFactory.AddInputs("10 22");
            commandFactory.AddInputs("E 2");

            Assert.AreEqual(1, commandFactory.commandSet.MoveCommands.Count);
        }

        [TestMethod]
        public void CreateCommandFactory_SingleMoveForwardWithMoreStepsTest()
        {
            CommandFactory commandFactory = new CommandFactory();
            commandFactory.AddInputs("2");
            commandFactory.AddInputs("10 22");
            commandFactory.AddInputs("E 300000");
            MoveForwardCommand moveForwardCommand = commandFactory.commandSet.MoveCommands[0];

            Assert.AreEqual(99999, moveForwardCommand.MoveSteps);
        }

        [TestMethod]
        public void CreateCommandFactory_SingleMoveForwardWithLessStepsTest()
        {
            CommandFactory commandFactory = new CommandFactory();
            commandFactory.AddInputs("2");
            commandFactory.AddInputs("10 22");
            commandFactory.AddInputs("E -1");
            MoveForwardCommand moveForwardCommand = commandFactory.commandSet.MoveCommands[0];

            Assert.AreEqual(1, moveForwardCommand.MoveSteps);
        }

        [TestMethod]
        public void CommandFactory_NullCommandSet()
        {
            CommandFactory commandFactory = new CommandFactory();
            commandFactory.AddInputs("3");
            commandFactory.AddInputs("10 22");
            commandFactory.AddInputs("E -1");

            CommandSet commandSet = commandFactory.GetCommandSet();

            Assert.IsNull(commandSet);
        }

        [TestMethod]
        public void CommandFactory_NotNullCommandSet()
        {
            CommandFactory commandFactory = new CommandFactory();
            commandFactory.AddInputs("3");
            commandFactory.AddInputs("10 22");
            commandFactory.AddInputs("E -1");
            commandFactory.AddInputs("E -1");
            commandFactory.AddInputs("E -1");

            CommandSet commandSet = commandFactory.GetCommandSet();

            Assert.IsNotNull(commandSet);
        }

        [TestMethod]
        public void CommandFactory_ThreeCommandSet()
        {
            CommandFactory commandFactory = new CommandFactory();
            commandFactory.AddInputs("3");
            commandFactory.AddInputs("10 22");
            commandFactory.AddInputs("E -1");
            commandFactory.AddInputs("E -1");
            commandFactory.AddInputs("E -1");

            CommandSet commandSet = commandFactory.GetCommandSet();

            Assert.AreEqual(3, commandSet.MoveCommands.Count);
        }
    }
}

