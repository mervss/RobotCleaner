﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using RobotCleanerFinalLibrary;

namespace RobotCleanerFinal.Test
{
    [TestClass]
    public class RobotTest
    {
        [TestMethod]
        public void CreateRobot_RoboCreation()
        {
            CommandFactory commandFactory = new CommandFactory();
            commandFactory.AddInputs("0");
            commandFactory.AddInputs("0 0");

            CommandSet commandSet = commandFactory.GetCommandSet();

            Robot robot = new Robot(commandSet, null);

            Assert.IsNotNull(robot);
        }

        [TestMethod]
        public void RunRobot_WithNoPositionChange()
        {
            CommandFactory commandFactory = new CommandFactory();
            commandFactory.AddInputs("0");
            commandFactory.AddInputs("0 0");

            CommandSet commandSet = commandFactory.GetCommandSet();
            Robot robot = new Robot(commandSet, null);

            robot.ExecuteCommands();

            Assert.AreEqual(commandSet.BeginningPosition.X, robot.Position.X);
            Assert.AreEqual(commandSet.BeginningPosition.Y, robot.Position.Y);
        }

        [TestMethod]
        public void RunRobot_ZeroPlaceCleanReport()
        {
            CommandFactory commandFactory = new CommandFactory();
            commandFactory.AddInputs("0");
            commandFactory.AddInputs("0 0");

            IReport reporter = new Reporter();

            CommandSet commandSet = commandFactory.GetCommandSet();
            Robot robot = new Robot(commandSet, reporter);

            robot.ExecuteCommands();
            string report = robot.ReportOutPut();

            Assert.AreEqual("=> Cleaned: 0", report);
        }

        [TestMethod]
        public void RunRobot_EmptyCommandSetWithNullReport()
        {
            CommandFactory commandFactory = new CommandFactory();
            commandFactory.AddInputs("0");
            commandFactory.AddInputs("0 0");

            CommandSet commandSet = commandFactory.GetCommandSet();
            Robot robot = new Robot(commandSet, null);

            robot.ExecuteCommands();
            string report = robot.ReportOutPut();

            Assert.AreEqual("=> Cleaned: unknown", report);
        }

        [TestMethod]
        public void RunRobot_SimpleCommandSetWithMovementBy1()
        {
            CommandFactory commandFactory = new CommandFactory();
            commandFactory.AddInputs("1");
            commandFactory.AddInputs("0 0");
            commandFactory.AddInputs("N 1");

            CommandSet commandSet = commandFactory.GetCommandSet();
            Robot robot = new Robot(commandSet, null);

            robot.ExecuteCommands();

            Assert.AreEqual(commandSet.BeginningPosition.X, robot.Position.X);
            Assert.AreEqual(commandSet.BeginningPosition.Y + 1, robot.Position.Y);
        }

        [TestMethod]
        public void RunRobot_OutofBoundsCommandSetWithMovements()
        {
            CommandFactory commandFactory = new CommandFactory();
            commandFactory.AddInputs("1");
            commandFactory.AddInputs("100000 100000");
            commandFactory.AddInputs("N 1");

            CommandSet commandSet = commandFactory.GetCommandSet();
            Robot robot = new Robot(commandSet, null, null, new Position(100000, 100000));

            robot.ExecuteCommands();

            Assert.AreEqual(commandSet.BeginningPosition.X, robot.Position.X);
            Assert.AreEqual(commandSet.BeginningPosition.Y, robot.Position.Y);
        }

        [TestMethod]
        public void RunRobot_SimpleCommandSetReportLocationCleaned()
        {
            CommandFactory commandFactory = new CommandFactory();
            commandFactory.AddInputs("1");
            commandFactory.AddInputs("20 20");
            commandFactory.AddInputs("N 1");

            CommandSet commandSet = commandFactory.GetCommandSet();
            IReport reporter = new Reporter();

            Robot robot = new Robot(commandSet, reporter, new Position(-100000, -100000), new Position(100000, 100000));

            robot.ExecuteCommands();

            string report = robot.ReportOutPut();

            Assert.AreEqual("=> Cleaned: 1", report);
        }

        [TestMethod]
        public void RunRobot_CommandSetWithPositionMovements()
        {
            CommandFactory commandFactory = new CommandFactory();
            commandFactory.AddInputs("4");
            commandFactory.AddInputs("0 0");
            commandFactory.AddInputs("N 5");
            commandFactory.AddInputs("E 5");
            commandFactory.AddInputs("S 5");
            commandFactory.AddInputs("W 5");

            CommandSet commandSet = commandFactory.GetCommandSet();

            IReport reporter = new Reporter();

            Robot robot = new Robot(commandSet, reporter, new Position(0, 0), new Position(5, 5));

            robot.ExecuteCommands();

            string report = robot.ReportOutPut();

            Assert.AreEqual("=> Cleaned: 20", report);
        }
    }
}
