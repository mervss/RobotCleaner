﻿using RobotCleanerFinalLibrary;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RobotCleanerFinal.Client
{
    class Program
    {
        static void Main(string[] args)
        {
            //Get input commands
            CommandFactory commandFactory = new CommandFactory();
            while (!commandFactory.IsInputComplete)
            {
                commandFactory.AddInputs(Console.ReadLine());
            }
            //Execute commands 
            Reporter reporter = new Reporter();
            Robot robot = new Robot(commandFactory.GetCommandSet(), reporter, new Position(0, 0), new Position(7, 7));
            robot.ExecuteCommands();

            //Reports number of places cleaned
            Console.WriteLine(reporter.ReportOutPut());

            Console.ReadLine();
        }
    }
}
