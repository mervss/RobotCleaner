﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace RobotCleanerFinalLibrary
{
    public class Reporter : IReport
    {
        private List<Position> cleanedLocations;
       
        public Reporter()
        {
            cleanedLocations = new List<Position>();
        }

        public string ReportOutPut()
        {
            return string.Format("=> Cleaned: {0}", cleanedLocations.Count+1);
        }

        public void RegisterNewPosition(Position position)
        {
            cleanedLocations.Add(position);
        }
    }
}

