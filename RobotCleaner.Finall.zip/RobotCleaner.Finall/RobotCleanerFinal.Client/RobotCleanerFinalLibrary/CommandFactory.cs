﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace RobotCleanerFinalLibrary
{
    public class CommandFactory
    {
        const int NumberofMinStep = 1;
        const int NumberofMaxSteps = 99999;
        List<string> inputStrings;

        internal readonly CommandSet commandSet;

        public CommandFactory()
        {
            inputStrings = new List<string>();
            commandSet = new CommandSet();
        }

        public void AddInputs(string input)
        {
            if (!IsInputComplete)
            {
                if (inputStrings.Count == 0)
                {
                    StCommandCount(input);
                }
                else if (inputStrings.Count == 1)
                {
                    StStartPosition(input);
                }
                else
                {
                    commandSet.MoveCommands.Add(ParseMoveCommand(input));
                }
                inputStrings.Add(input);
            }
        }

        private MoveForwardCommand ParseMoveCommand(string input)
        {
            MoveForwardCommand moveForwardCommand = new MoveForwardCommand();
            string[] inputBts = input.Split(null);
            if (inputBts.Length > 1)
            {
                switch (inputBts[0].ToUpper())
                {
                    case "E":
                        moveForwardCommand.MoveDirection = Direction.East;
                        break;
                    case "W":
                        moveForwardCommand.MoveDirection = Direction.West;
                        break;
                    case "N":
                        moveForwardCommand.MoveDirection = Direction.North;
                        break;
                    case "S":
                        moveForwardCommand.MoveDirection = Direction.South;
                        break;
                    default:
                        moveForwardCommand.MoveDirection = Direction.Unknown;
                        break;
                }

                moveForwardCommand.MoveSteps = int.Parse(inputBts[1]);

                if (moveForwardCommand.MoveSteps > NumberofMaxSteps) moveForwardCommand.MoveSteps = NumberofMaxSteps;
                if (moveForwardCommand.MoveSteps < NumberofMinStep) moveForwardCommand.MoveSteps = NumberofMinStep;
            }
            return moveForwardCommand;
        }

        private void StStartPosition(string input)
        {
            string[] locationBts = input.Split(null);
            if (locationBts.Length > 1)
            {
                int x = int.Parse(locationBts[0]);
                int y = int.Parse(locationBts[1]);

                commandSet.BeginningPosition = new Position(x, y);
            }
        }

        private void StCommandCount(string input)
        {
            commandSet.CommandsCount = int.Parse(input);
            if (commandSet.CommandsCount < 0) { commandSet.CommandsCount = 0; }
            else if (commandSet.CommandsCount > 10000) { commandSet.CommandsCount = 10000; }
        }


        public bool IsInputComplete
        {
            get
            {
                return inputStrings.Count == commandSet.CommandsCount + 2;
            }
        }

        public CommandSet GetCommandSet()
        {
            if (IsInputComplete)
            {
                return commandSet;
            }
            return null;
        }
    }
}
