﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RobotCleanerFinalLibrary
{
    public enum Direction
    {
        East,
        West,
        North,
        South,
        Unknown
    }
}

