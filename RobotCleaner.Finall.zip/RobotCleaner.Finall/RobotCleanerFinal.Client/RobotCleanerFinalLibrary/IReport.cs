﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace RobotCleanerFinalLibrary
{
    public interface IReport
    {
        string ReportOutPut();

        void RegisterNewPosition(Position Position);
    }
}
